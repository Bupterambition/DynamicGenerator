//
//  DynamicTest.h
//  DynamicGenerator
//
//  Created by Senmiao on 2016/11/25.
//  Copyright © 2016年 Senmiao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DynamicTest : NSObject

@end
